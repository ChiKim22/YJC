package Main;

public class Main2 {
	public static void main(String[] args) {
		System.out.println("집 언제 갈건데.");
	}
}
