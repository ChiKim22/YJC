package CH7;

public class Bus extends Vehicle{


}
