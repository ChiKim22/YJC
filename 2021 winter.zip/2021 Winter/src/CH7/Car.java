package CH7;

public class Car extends Vehicle{
	
}
