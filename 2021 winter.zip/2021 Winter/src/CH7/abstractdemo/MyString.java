package CH7.abstractdemo;
import java.lang.String;
public final class MyString {

}
