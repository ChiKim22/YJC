package CH8;

public class Main {

	public static void main(String[] args) {
		MyFrame frame = new MyFrame();
		
	}
}
