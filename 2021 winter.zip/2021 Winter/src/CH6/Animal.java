package CH6;

public class Animal {
	
	public void animal() {
		
	}

	public void speak() {
		// TODO Auto-generated method stub
		
	}
	
}
