package CH6;

import java.util.Scanner;

public class Java0104 {
    // quit 이면 반복문 종료
    // 사용자에게 문자열을 받아서 문자열이 www 로 시작하는지를 검사하는 프로그램을 작성해보자.
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // while(true) {
        //     System.out.println("문자열을 입력하세요");
        //     String str = input.nextLine();
        //     if(str.equals("quit")) {
        //         break;
        //     }
        //    if(str.substring(0,3).equals("www")) {
        //    // if(str.startsWith("www")) {
        //         System.out.println("www로 시작합니다");
        //     }
        //     else {
        //         System.out.println("시작안함");
        //     }
        // }

//        int[] arr  = new int[3];
//        arr[0] = 1;
//        arr[1] = 2;
//        arr[2] = 3;
//
//        for(int n : arr) {
//            System.out.println(n);
//        }
//
//        MyArray arr2 = new MyArray();
//        arr2.put(0,10);
//        arr2.put(6,20);
//
//        System.out.println(arr2.get(1));
        
      
/*        
        //2021 0105
        Television tv1 = new Television(5, 20, false);
//        tv1.setChannel(5);
//        tv1.setVolume(20);
//        tv1.setOnOff(false);
        System.out.println("tv1:"+tv1.toString());
        
        Television tv2 = new Television(7, 30, true);
//        tv2.setChannel(7);
//        tv2.setVolume(30);
//        tv2.setOnOff(true);
        System.out.println("tv2:"+tv2.toString());
*/
        
        /*
        Box box1 = new Box();
        Box box2 = new Box(20, 20, 30);
        
        System.out.println(box1.toString()); //상자 밑변의 가로 세로 높이 부피 ==0;
        System.out.println(box2.toString()); // 상자 밑변의 가로, 세로, 높이, 부피 == 20, 20, 30, 12000
        */
        
       /*
        Date date1 = new Date(); //1900/01/01
        Date date2 = new Date(2021, 1, 5); //2021/01/05
        Date date3 = new Date(2021); //2021/01/01
        
       	System.out.println(date1);
       	System.out.println(date2);
       	System.out.println(date3);
       */ 
        
        /*
        Time time1 = new Time(); //00:00:00
        Time time2 = new Time(13, 27, 6); //13:27:6
        Time time3 = new Time(99,77,66); //00:00:00
        Time time4 = new Time(15,77,30); //15:00:30
        
        System.out.println(time1);
        System.out.println(time2);
        System.out.println(time3);
        System.out.println(time4);
        */
        
        /*
        Point point = new Point(25, 78);
        Circle circle = new Circle(point, 20);
        
        System.out.println(circle);
        
        Circle c2 = new Circle();
        System.out.println(c2);
        */
        
        
        
//        int val =3;
//        test(val);
//        System.out.println(val);
//        {
//        public static void test(int n) 
//        	n = n+1;
//        }
        
    }
}
