package CH6;

public class Math {

		public static final double PI = 3.14; // 공유.
	
	public int add(int n1, int n2) {
		return n1+n2;
	}
	
}
