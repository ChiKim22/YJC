package ch05.oop;


public class Professor extends Person{

	void lecture() {
		System.out.println(name+"교수가 수업을 합니다.");
	}
}
