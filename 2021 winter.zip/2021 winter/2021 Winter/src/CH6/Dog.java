package CH6;

public class Dog extends Animal{
	
	@Override // annotation
	public void speak() {
		System.out.println("멍멍");
	}
	
}
