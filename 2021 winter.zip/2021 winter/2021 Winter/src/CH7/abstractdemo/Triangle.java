package CH7.abstractdemo;

public class Triangle extends Shape{

	@Override
	public void draw() {
		System.out.println("삼각형 그리기");
		// TODO Auto-generated method stub
		
	}
	
	

}
