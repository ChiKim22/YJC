package CH7.abstractdemo;

public class Ractangle extends Shape {

	private int width,length;
	@Override
	public void draw() {
		System.out.println("사각형 그리기");
		// TODO Auto-generated method stub
		
	}

		
}
