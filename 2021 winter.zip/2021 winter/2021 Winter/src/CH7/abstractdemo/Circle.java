package CH7.abstractdemo;

public class Circle extends Shape {

	@Override
	public void draw() {
		System.out.println("원 그리기");
		// TODO Auto-generated method stub
		
	}
	

}
