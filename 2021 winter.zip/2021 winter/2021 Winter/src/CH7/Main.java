package CH7;

public class Main {

	public static void main(String[] args) {
//		Bus bus = new Bus();
//		bus.setSpeed(100);
//	
//		Car car = new Car();
//		car.setSpeed(120);
//	
//		Truck truck = new Truck();
//		truck.setSpeed(90);
		
//		Ractangle r = new Ractangle();
//		r.draw();
		
//		Manager m = new Manager("Tom", "USA",10000000, 123456, 500000);
//		System.out.println(m);
//		m.test();
		
//		Derived d = new Derived();
//		Ractangle r = new Ractangle();
		
		/*
		 * 부모 클래스에 기본 생성자(매개변수를 가지지 않는 생성자)가 구현되어 있지 않으면,
		 * 자식 클래스의 생성자에서, 부모 클래스의 생성자를 명시적으로 호출해야 한다.
		 */
		
	}
}
