package CH7;

public class Truck extends Vehicle{

}
