package CH7;

public class Animal {

	private double weight;
	private String picture;
	
	void eat() {
		System.out.println("eat() Called");
	}
	void sleep() {
		System.out.println("sleep() Called");
	}
	
	
}
