package CH9;

public class Main5 {
	
	public static void main(String[] args) {
		String s ="Kim       ";
		System.out.println("["+s+"]");
		
		System.out.println("After trim");
		String s2 = s.trim();
		System.out.println("["+s2+"]");
	}
}
