package CH9;

public class FlyingCar implements Drivable, Flyable{


	@Override
	public void drive() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Fly() {
		// TODO Auto-generated method stub
		
	}


}
