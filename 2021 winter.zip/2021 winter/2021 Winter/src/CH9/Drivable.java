package CH9;

public interface Drivable {
	void drive();
}
