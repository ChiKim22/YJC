package CH9;

public interface RemoteControl {
	
	void turnOn();
	void turnOff();
	
//	default void volumeUp() {
//		
//	};
//	default void volumeDown() {
//		
//	};
	
	
}
