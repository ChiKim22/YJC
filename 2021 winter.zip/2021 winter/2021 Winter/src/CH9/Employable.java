package CH9;

public interface Employable {
	String getName();
//	
//	static boolean isEmpty(String str) {
//		
////		if(str == null || str.trim().length()==0)
////			System.out.prinltn(s);
//		
//	}

	static boolean isEmpty(String name) {
		// TODO Auto-generated method stub
		return false;
	}
}
