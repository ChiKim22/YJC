package CH9;

public interface MyInterface {

	void test();
	int test2();
	double test3();
	
}
