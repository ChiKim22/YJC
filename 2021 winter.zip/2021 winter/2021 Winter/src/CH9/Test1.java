package CH9;

public class Test1 extends MyAbstractClass{

	@Override
	public void test1() {
		// TODO Auto-generated method stub
		super.test1();
	}

}
