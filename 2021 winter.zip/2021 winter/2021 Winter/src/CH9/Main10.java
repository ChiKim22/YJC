import java.util.*;

public class Main10 {
    public static void main(String[] args){
        MyCalculator c = (n1, n2) -> n1+n2 ;

        int val = c.calculate(5,92);
        System.out.println(val);

        java.util.Scanner scanner = new java.util.Scanner(System.in);
        Calendar cal = Calendar.getInstance();
        Date date = new Date();

        

    }
}
