package CH9;

public interface Flyable{

	public void Fly();


}
