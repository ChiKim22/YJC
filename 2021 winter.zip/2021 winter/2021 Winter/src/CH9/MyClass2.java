package CH9;

public class MyClass2 {

}
