package CH9;

public class MyAbstractClass {

	public void test1() {
		
	}
	public void test2() {
		
	}
	public void test3() {
		
	}
	public void test4() {
		
	}
}
