package CH8;

public interface MyInterface {
	
	void test1();
	void test2();
	void test3();

}
