package Main;

 import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int h =input.nextInt();
		int m =input.nextInt();
		
		if(h>=0|| h<24) {
			if(m>=0 || m<60) {
				
			}
		}
		
		
		/*
		double x = input.nextInt();
		double y = input.nextInt();
		
		if(x>0) {
			if(y<0) {
				System.out.print("");
			}
			else {
				System.out.print("1");
			}
		}
		if(x<0) {
			if(y>0) {
				System.out.print("2");			
		}else {
			System.out.print("3");
		}
		}
		*/
		
	}
}
