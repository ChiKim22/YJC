package Test; //7월 첫쨰주
/**
 * New program
 * Frist program made
 * @author kim
 * @since 2020/7/9
 */
public class Test {
	
	public static void main(String[] args) {
		/*
		 * This program
		 * First made
		 * program
		 * XD
		 */
		System.out.println("Hello World"); // Display World
		System.out.println("I'm a new Java programmer.");
		
		int n = 9; //정수표현 = n
		
		String s = "He is " + 22 + " Years old" ; // String = 표
		
		System.out.println(s);
		
		System.out.println(Long.MAX_VALUE);
		System.out.println(Long.MIN_VALUE);
		
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		
		System.out.println(Short.MAX_VALUE);
		System.out.println(Short.MIN_VALUE);
		
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Byte.MIN_VALUE);
	}

}
